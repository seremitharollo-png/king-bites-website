(() => {
  const C = CONFIG;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const id = t => t.toLowerCase().replace(/[^a-z]+/g, "-");
  const hue = n => 5 + (n * 17) % 50;
  const wa = m => `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(m || C.orderMsg)}`;
  const tile = (e, n, cls = "tile", img) => img
    ? `<img class="${cls}" src="${img}" alt="" loading="lazy">`
    : `<div class="${cls}" style="--h:${hue(n)}" aria-hidden="true">${e}</div>`;
  const all = C.menu.flatMap(c => c.items);

  /* Header + footer (shared on every page) */
  const pages = [["Home", "index.html"], ["Menu", "menu.html"], ["About", "about.html"], ["Gallery", "gallery.html"], ["Contact", "contact.html"]];
  const here = location.pathname.split("/").pop() || "index.html";
  $("#site-header").innerHTML = `<div class="wrap bar"><a class="brand" href="index.html">👑 ${C.name}</a>
    <button class="burger" aria-expanded="false" aria-controls="nav" aria-label="Open menu"><span></span></button>
    <nav id="nav" aria-label="Main">${pages.map(([t, h]) => `<a href="${h}"${h === here ? ' aria-current="page"' : ""}>${t}</a>`).join("")}
    <a class="btn btn-wa" data-wa>💬 Order on WhatsApp</a></nav></div>`;
  $("#site-footer").innerHTML = `<div class="wrap foot"><div><p class="brand">👑 ${C.name}</p><p>${C.address}</p></div>
    <div><p><a data-tel></a><br><a data-mail></a></p></div>
    <div class="soc">${Object.entries(C.socials).map(([n, u]) => `<a href="${u}" target="_blank" rel="noopener">${n}</a>`).join("")}</div></div>
    <p class="wrap legal">Demo website with placeholder details. Not a real business.</p>
    <a class="btn btn-wa fab" data-wa aria-label="Order on WhatsApp">💬 Order</a>`;

  /* Mobile nav */
  const b = $(".burger"), nav = $("#nav");
  b.onclick = () => { const o = nav.classList.toggle("open"); b.setAttribute("aria-expanded", o); b.setAttribute("aria-label", o ? "Close menu" : "Open menu"); };
  nav.onclick = e => { if (e.target.closest("a")) { nav.classList.remove("open"); b.setAttribute("aria-expanded", false); } };

  /* Templates */
  const item = ([n, d, p, e, img], i) => `<li class="item">${tile(e, i, "tile", img)}<div><h3>${n}</h3><p>${d}</p>
    <a class="order" data-wa="Hi King Bites Grill, I would like to order: ${n}.">Order this</a></div><b class="price">R${p}</b></li>`;
  const card = ([n, d, p, e, img], i) => `<article class="card">${tile(e, i, "tile big", img)}<h3>${n}</h3><p>${d}</p>
    <p class="row between"><b class="price">R${p}</b><a class="order" data-wa="Hi King Bites Grill, I would like to order: ${n}.">Order this</a></p></article>`;

  /* Menu page */
  const M = $("#menu");
  if (M) {
    $("#menu-nav").innerHTML = C.menu.map(c => `<a href="#${id(c.cat)}">${c.cat}</a>`).join("");
    let k = 0;
    M.innerHTML = C.menu.map(c => `<section class="cat" id="${id(c.cat)}"><h2>${c.cat}</h2><ul class="items">${c.items.map(i => item(i, k++)).join("")}</ul></section>`).join("");
  }
  /* Home: featured, ticket, reviews */
  const F = $("#featured");
  const feat = C.featured.map(n => all.find(i => i[0] === n)).filter(Boolean);
  if (F) F.innerHTML = feat.map((i, n) => card(i, n)).join("");
  const T = $("#ticket-lines");
  if (T) {
    T.innerHTML = feat.slice(0, 2).map(i => `<li><span>1× ${i[0]}</span><span>R${i[2]}</span></li>`).join("");
    $("#ticket-total").textContent = "R" + feat.slice(0, 2).reduce((s, i) => s + i[2], 0);
    $("#ticket-btn").dataset.wa = `Hi King Bites Grill, I would like to order: ${feat.slice(0, 2).map(i => i[0]).join(" and ")}.`;
  }
  const R = $("#reviews");
  if (R) R.innerHTML = C.reviews.map(([q, a]) => `<figure class="rev"><blockquote>${q}</blockquote><figcaption>${a}<small>Sample review (fictional)</small></figcaption></figure>`).join("");
  /* Gallery */
  const G = $("#gallery");
  if (G) G.innerHTML = C.gallery.map(([e, l, img], n) => `<figure class="g">${tile(e, n * 2, "gt", img)}<figcaption>${l}</figcaption></figure>`).join("");

  /* Fill shared business info */
  $$("[data-hours]").forEach(e => e.innerHTML = C.hours.map(([d, t]) => `<div><dt>${d}</dt><dd>${t}</dd></div>`).join(""));
  $$("[data-address]").forEach(e => e.textContent = C.address);
  $$("[data-tel]").forEach(e => { e.href = "tel:" + C.phone.replace(/\s/g, ""); e.textContent = C.phone; });
  $$("[data-mail]").forEach(e => { e.href = "mailto:" + C.email; e.textContent = C.email; });
  $$("[data-map]").forEach(e => { e.href = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(C.mapQuery); e.target = "_blank"; e.rel = "noopener"; });
  $$("[data-map-embed]").forEach(e => e.src = "https://maps.google.com/maps?q=" + encodeURIComponent(C.mapQuery) + "&output=embed");
  $$("[data-social]").forEach(e => e.innerHTML = Object.entries(C.socials).map(([n, u]) => `<a class="btn btn-line" href="${u}" target="_blank" rel="noopener">${n}</a>`).join(""));
  $$("[data-wa]").forEach(a => { a.href = wa(a.dataset.wa); a.target = "_blank"; a.rel = "noopener"; });
})();
