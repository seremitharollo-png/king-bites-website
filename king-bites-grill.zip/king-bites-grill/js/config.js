/* ==========================================================
   EDIT THIS FILE to customise the whole website.
   Everything below is PLACEHOLDER data for a fictional business.
   ========================================================== */
const CONFIG = {
  name: "King Bites Grill",

  /* WhatsApp number: international format, digits only (no + or spaces).
     South Africa example: 27821234567. PLACEHOLDER below. */
  whatsapp: "27000000000",
  orderMsg: "Hi King Bites Grill, I would like to place an order.",

  /* CONTACT (placeholders) */
  phone: "+27 00 000 0000",
  email: "hello@kingbitesgrill.example",
  address: "12 Placeholder Street, Johannesburg, Gauteng, 2000",
  mapQuery: "Johannesburg, Gauteng, South Africa", // used for the map embed + directions

  /* OPENING HOURS */
  hours: [
    ["Monday to Thursday", "10:00 – 21:00"],
    ["Friday and Saturday", "10:00 – 23:00"],
    ["Sunday", "11:00 – 20:00"],
    ["Public holidays", "11:00 – 18:00"]
  ],

  /* SOCIAL LINKS (replace with the client's real pages) */
  socials: {
    Facebook: "https://www.facebook.com/",
    Instagram: "https://www.instagram.com/",
    TikTok: "https://www.tiktok.com/"
  },

  /* MENU PRICES (rand). Item format: [name, description, price, emoji, optionalImageUrl]
     Avoid quote marks inside names. */
  menu: [
    { cat: "Burgers", items: [
      ["Classic Grill Burger", "Flame-grilled beef patty, lettuce, tomato, onion and our house sauce.", 55, "🍔"],
      ["King Double Burger", "Two patties, double cheese, crispy onions and smoky BBQ glaze.", 85, "🍔"],
      ["Spicy Chicken Burger", "Crumbed chicken breast, peri-peri mayo and crunchy slaw.", 65, "🍔"]
    ]},
    { cat: "Chicken", items: [
      ["Quarter Chicken and Chips", "Flame-grilled quarter chicken with a mountain of chips.", 70, "🍗"],
      ["Half Chicken", "Marinated overnight, grilled to order. Choose mild or hot.", 110, "🍗"],
      ["Chicken Strips (6)", "Golden crumbed strips with your choice of dipping sauce.", 60, "🍗"]
    ]},
    { cat: "Wings", items: [
      ["6 Hot Wings", "Fiery peri-peri glaze. Not for the faint-hearted.", 55, "🔥"],
      ["12 Lemon-Herb Wings", "Tangy, fresh and lightly spiced. Great for sharing.", 99, "🔥"],
      ["8 Sticky BBQ Wings", "Sweet, smoky and finger-licking sticky.", 75, "🔥"]
    ]},
    { cat: "Chips", items: [
      ["Slap Chips", "Soft, salty and vinegar-ready. The real Joburg way.", 25, "🍟"],
      ["Cheesy Chips", "Hot chips smothered in melted cheddar.", 40, "🍟"],
      ["Loaded Chips", "Cheese, bacon bits, jalapeños and sauce.", 55, "🍟"]
    ]},
    { cat: "Platters", items: [
      ["Braai Platter for 2", "Chicken, wings, chips, slaw and two sauces.", 220, "🍖"],
      ["Family Feast", "Whole chicken, 12 wings, large chips and 4 drinks.", 380, "🍖"],
      ["Wing Platter", "20 mixed wings with chips and dipping sauces.", 150, "🍖"]
    ]},
    { cat: "Combo Meals", items: [
      ["King Burger Combo", "Classic burger, small chips and a 330ml drink.", 89, "🥡"],
      ["Wings Combo", "6 wings, small chips and a 330ml drink.", 95, "🥡"],
      ["King Kota Combo", "Quarter loaf, chips, cheese, polony, atchar and a drink.", 60, "🥡"]
    ]},
    { cat: "Drinks", items: [
      ["Soft Drink 330ml", "Ask for today's flavours.", 18, "🥤"],
      ["Iced Tea 500ml", "Peach or lemon.", 20, "🥤"],
      ["Milkshake", "Vanilla, chocolate or strawberry.", 38, "🥤"]
    ]}
  ],

  /* HOMEPAGE: featured items (must match menu names exactly). The first two also fill the order slip. */
  featured: ["King Double Burger", "6 Hot Wings", "King Kota Combo", "Braai Platter for 2"],

  /* SAMPLE REVIEWS (fictional placeholders, clearly labelled on the page) */
  reviews: [
    ["Best wings this side of the M1. Hot, fast and the price is right.", "Thabo M., Soweto"],
    ["Ordered on WhatsApp during lunch and it was ready in 15 minutes.", "Lerato K., Sandton"],
    ["The King Kota is huge. Feeds me for the whole afternoon.", "Sipho N., Braamfontein"]
  ],

  /* GALLERY: [emoji, label, optionalImageUrl]. Add image URLs once you have permission-cleared photos. */
  gallery: [
    ["🍔", "Double stack"], ["🍗", "Grilled chicken"], ["🔥", "Hot wings"], ["🍟", "Slap chips"],
    ["🥡", "Kota combo"], ["🍖", "Braai platter"], ["🥤", "Cold drinks"], ["👨‍🍳", "On the grill"]
  ]
};
